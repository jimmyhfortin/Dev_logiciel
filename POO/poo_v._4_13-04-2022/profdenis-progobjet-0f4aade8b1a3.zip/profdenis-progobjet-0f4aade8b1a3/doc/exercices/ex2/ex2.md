# Programmation Orientée Objet

## Exercice 2 : Dessiner des figures géométriques, 1ère version OO

En prenant la classe `ShapesV2.HLine` comme exemple, pour chacune des méthodes de la classe `ShapesV1.Draw`, créez une classe correspondante dans le projet `ShapesV2` qui contient une méthode `public void Draw(Canvas canvas)`, qui dessine la figure géométrique sur le `Canvas`.