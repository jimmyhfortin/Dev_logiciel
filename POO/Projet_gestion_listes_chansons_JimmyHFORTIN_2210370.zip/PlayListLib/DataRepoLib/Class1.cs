﻿namespace DataRepoLib;

public class Class1
{
}