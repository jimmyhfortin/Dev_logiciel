Merci Hind pour tout c’est cours et pour la belle énergie que tu as mise dans notre apprentissage je suis impatient de te retrouver pour les bases de SQL comme enseignante! 

Merci. 
Jimmy H. Fortin 